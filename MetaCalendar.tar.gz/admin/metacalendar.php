﻿<?php
// Erlaube Zugriff nur von Joomla! aus:
defined('_JEXEC') or die;
?>
<h1>
  MetaCalendar Backend
</h1>

